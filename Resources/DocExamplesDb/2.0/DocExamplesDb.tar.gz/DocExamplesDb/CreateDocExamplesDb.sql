CREATE SCHEMA SPLICEBBALL;

CREATE TABLE SPLICEBBALL.Players(
    ID           SMALLINT NOT NULL PRIMARY KEY,
    Team         VARCHAR(64) NOT NULL,
    Name         VARCHAR(64) NOT NULL,
    Position     CHAR(2),
    DisplayName  VARCHAR(24),
    BirthDate    DATE
    );
    
CREATE TABLE SPLICEBBALL.Salaries(
    ID           SMALLINT NOT NULL PRIMARY KEY,
    Season       SMALLINT DEFAULT 2015,
    Salary       BIGINT DEFAULT 0
    );
    
CREATE TABLE SPLICEBBALL.Batting(
    ID           SMALLINT NOT NULL PRIMARY KEY,
    Games        SMALLINT,
    PlateAppearances    SMALLINT,
    AtBats       SMALLINT,
    Runs         SMALLINT,
    Hits         SMALLINT,
    Doubles      SMALLINT,
    Triples      SMALLINT,
    HomeRuns     SMALLINT,
    RBI          SMALLINT,
    StolenBases  SMALLINT,
    CaughtStealing      SMALLINT,
    Walks        SMALLINT,
    Strikeouts   SMALLINT,
    DoublePlays  SMALLINT,
    HitByPitches SMALLINT,
    SacrificeHits       SMALLINT,
    SacrificeFlies      SMALLINT,
    IntentionalWalks    SMALLINT,
    TotalBases   SMALLINT,
    Singles      SMALLINT,
    OnBasePercentage    DECIMAL(7,5),
    Slugging     DECIMAL(7,5),
    OnBasePlusSlugging  DECIMAL(7,5),
    Average      DECIMAL(7,5)
    );
    
CREATE TABLE SPLICEBBALL.Pitching(
    ID          SMALLINT NOT NULL PRIMARY KEY,
    Wins        SMALLINT,
    Losses      SMALLINT,
    Games       SMALLINT,
    GamesStarted    SMALLINT,
    GamesFinished   SMALLINT,
    CompleteGames   SMALLINT,
    Shutouts    SMALLINT,
    Saves       SMALLINT,
    Innings     DECIMAL(5,2),
    Hits        SMALLINT,
    Runs        SMALLINT,
    EarnedRuns  SMALLINT,
    HomeRuns    SMALLINT,
    Walks       SMALLINT,
    IntentionalWalks     SMALLINT,
    Strikeouts  SMALLINT,
    HitBatters  SMALLINT,
    Balks       SMALLINT,
    WildPitches SMALLINT,
    BattersFaced         SMALLINT,
    FieldingIndependent  DECIMAL(5,2),
    ERA         DECIMAL(7,5),
    WHIP        DECIMAL(7,5),
    HitsPerNine          DECIMAL(7,5),
    HomeRunsPerNine      DECIMAL(7,5),
    WalksPerNine         DECIMAL(7,5),
    StrikeoutsPerNine    DECIMAL(7,5),
    StrikeoutsToWalks    DECIMAL(7,5),
    Season      SMALLINT DEFAULT 2015
    );
    
CREATE TABLE SPLICEBBALL.Fielding(
    ID          SMALLINT NOT NULL PRIMARY KEY,
    FldGames    SMALLINT,
    Chances     SMALLINT,
    Putouts     SMALLINT,
    Assists     SMALLINT,
    Errors      SMALLINT,
    FldDoublePlays    SMALLINT,
    Percentage        DECIMAL(7,5),
    TZAboveAvg        SMALLINT,
    TZAboveAveragePer1200    SMALLINT,
    RunsSaved   SMALLINT,
    RunsSavedAboveAvg  SMALLINT,
    RangeFactorPerNine DECIMAL(7,5),
    RangeFactorPerGame DECIMAL(7,5),
    PassedBalls SMALLINT,
    WildPitches SMALLINT,
    FldStolenBases     SMALLINT,
    FldCaughtStealing  SMALLINT,
    FldCaughtStealingPercent        DECIMAL(7,5),
    FldLeagueCaughtStealingPercent  DECIMAL(7,5),
    Pickoffs    SMALLINT,
    FldInnings  DECIMAL(10,5),
    Season      SMALLINT DEFAULT 2015
    );

CALL SYSCS_UTIL.IMPORT_DATA('SPLICEBBALL', 'Players',
	null, './DocExamplesDb/Players.csv',
	null, null, null, null, null, 0, null, true, null);
	
CALL SYSCS_UTIL.IMPORT_DATA('SPLICEBBALL', 'Salaries',
	null, './DocExamplesDb/Salaries.csv',
	null, null, null, null, null, 0, null, true, null);
	
CALL SYSCS_UTIL.IMPORT_DATA('SPLICEBBALL', 'Batting',
	null, './DocExamplesDb/Batting.csv',
	null, null, null, null, null, 0, null, true, null);
	
CALL SYSCS_UTIL.IMPORT_DATA('SPLICEBBALL', 'Pitching',
	null, './DocExamplesDb/Pitching.csv',
	null, null, null, null, null, 0, null, true, null);
	
CALL SYSCS_UTIL.IMPORT_DATA('SPLICEBBALL', 'Fielding',
	null, './DocExamplesDb/Fielding.csv',
	null, null, null, null, null, 0, null, true, null);


